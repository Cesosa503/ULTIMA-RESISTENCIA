﻿using Microsoft.AspNetCore.Mvc;
using MongoAPI.DTOs;
using MongoAPI.Models;
using MongoAPI.Services;

namespace MongoAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TicketController : ControllerBase
    {
        private readonly TicketService _service;

        public TicketController(TicketService service)
        {
            _service = service;
        }

        // Crear
        [HttpPost]
        public async Task<IActionResult> Create(TicketDto dto)
        {
            var ticket = new Ticket
            {
                Title = dto.Title,
                Description = dto.Description,
                StartDate = dto.StartDate,
                EndDate = dto.EndDate,
                Hours = dto.Hours
            };

            await _service.Create(ticket);
            return Ok(ticket);
        }

        // Obtener todos
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _service.GetAll());
        }

        // Obtener por ID
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(string id)
        {
            var ticket = await _service.GetById(id);

            if (ticket == null)
                return NotFound();

            return Ok(ticket);
        }

        //  Actualizar
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(string id, TicketDto dto)
        {
            var ticket = await _service.GetById(id);

            if (ticket == null)
                return NotFound();

            ticket.Title = dto.Title;
            ticket.Description = dto.Description;
            ticket.StartDate = dto.StartDate;
            ticket.EndDate = dto.EndDate;
            ticket.Hours = dto.Hours;

            await _service.Update(id, ticket);

            return Ok(ticket);
        }

        // Borrado lógico
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(string id)
        {
            await _service.Delete(id);
            return Ok("Eliminado lógico");
        }

        [HttpGet("filter")]
        public async Task<IActionResult> Filter(string? title, string? status, DateTime? startDate)
        {
            var result = await _service.Filter(title, status, startDate);
            return Ok(result);
        }

        [HttpGet("paginated")]
        public async Task<IActionResult> GetPaginated(int page = 1, int pageSize = 5)
        {
            var result = await _service.GetPaginated(page, pageSize);
            return Ok(result);
        }
    }
}
