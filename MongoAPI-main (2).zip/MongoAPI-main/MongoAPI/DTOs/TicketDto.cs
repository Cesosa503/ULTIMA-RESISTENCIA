﻿namespace MongoAPI.DTOs
{
    public class TicketDto
    {
        public string Title { get; set; }
        public string Description { get; set; }

        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }

        public decimal Hours { get; set; }
    }
}