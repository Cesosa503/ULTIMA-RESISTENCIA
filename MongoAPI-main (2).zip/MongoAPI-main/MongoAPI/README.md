﻿# MongoAPI 

## *Descripción

MongoAPI es una API REST desarrollada en **.NET** que permite la gestión de tickets utilizando **MongoDB** como base de datos.
Incluye operaciones CRUD, filtros avanzados, paginación y borrado lógico.

---

## * Tecnologías utilizadas

* .NET 10
* MongoDB
* Docker
* Swagger (OpenAPI)

---

### * Requisitos

* .NET SDK instalado
* Docker Desktop
* MongoDB (contenedor Docker)

---

### * Ejecutar MongoDB en Docker

```bash
docker run -d -p 27017:27017 --name mongodb mongo
```

---

### * Ejecutar la API

```bash
dotnet run
```

---
## * Base URL

```plaintext
http://localhost:5149
```

---

## * Endpoints de la API

### * Crear Ticket

```http
POST /api/Ticket
```

### * Obtener todos los tickets

```http
GET /api/Ticket
```

### * Obtener ticket por ID

```http
GET /api/Ticket/{id}
```

### * Actualizar ticket

```http
PUT /api/Ticket/{id}
```

### * Eliminar ticket 

```http
DELETE /api/Ticket/{id}
```

---

## *Filtros (

Permite filtrar tickets por diferentes criterios:

```http
GET /api/Ticket/filter?title=Error&status=Open&startDate=2026-04-10
```

### *Criterios disponibles:

 `title`
 `status`
 `startDate`

---

## * Paginación 

Permite obtener resultados por páginas:

```http
GET /api/Ticket/paginated?page=1&pageSize=2
```

### * Parámetros:

 `page`: número de página
 `pageSize`: cantidad de registros por página

---

## *Borrado lógico

El sistema no elimina físicamente los registros, en su lugar utiliza:

```json
"isDeleted": true
```

Esto permite mantener la integridad de los datos.

---

## ** Ejemplo de respuesta

```json
{
  "id": "123456",
  "title": "Error sistema",
  "description": "No carga módulo",
  "startDate": "2026-04-10",
  "endDate": "2026-04-11",
  "hours": 3,
  "status": "Open",
  "isDeleted": false
}
```

---

## * Pruebas

La API puede ser probada utilizando Swagger:

```plaintext
http://localhost:5149/swagger
```

---

## * Funcionalidades implementadas

 API REST funcional
 CRUD completo
 Filtros (3 criterios)
 Paginación
 Borrado lógico
 Uso de MongoDB con driver oficial
 Documentación con Swagger

---
## * Autor
Proyecto desarrollado por Gruppo A.
