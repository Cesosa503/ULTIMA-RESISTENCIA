﻿using MongoDB.Driver;
using MongoAPI.Models;

namespace MongoAPI.Repositories
{
    public class TicketRepository
    {
        private readonly IMongoCollection<Ticket> _collection;

        public TicketRepository(IConfiguration config)
        {
            var client = new MongoClient(config["Mongo:ConnectionString"]);
            var database = client.GetDatabase(config["Mongo:DatabaseName"]);
            _collection = database.GetCollection<Ticket>(config["Mongo:CollectionName"]);
        }

        //  Obtener todos
        public async Task<List<Ticket>> GetAll()
        {
            return await _collection.Find(t => !t.IsDeleted).ToListAsync();
        }

        //  Obtener por ID
        public async Task<Ticket> GetById(string id)
        {
            return await _collection
                .Find(t => t.Id == id && !t.IsDeleted)
                .FirstOrDefaultAsync();
        }

        // Crear
        public async Task Create(Ticket ticket)
        {
            await _collection.InsertOneAsync(ticket);
        }

        // Actualizar
        public async Task Update(string id, Ticket ticket)
        {
            await _collection.ReplaceOneAsync(t => t.Id == id, ticket);
        }

        //  Borrado lógico
        public async Task Delete(string id)
        {
            var update = Builders<Ticket>.Update.Set(t => t.IsDeleted, true);

            await _collection.UpdateOneAsync(
                t => t.Id == id,
                update
            );
        }
        public async Task<List<Ticket>> Filter(string? title, string? status, DateTime? startDate)
        {
            var filter = Builders<Ticket>.Filter.Empty;

            if (!string.IsNullOrEmpty(title))
                filter &= Builders<Ticket>.Filter.Regex(t => t.Title, new MongoDB.Bson.BsonRegularExpression(title, "i"));

            if (!string.IsNullOrEmpty(status))
                filter &= Builders<Ticket>.Filter.Eq(t => t.Status, status);

            if (startDate.HasValue)
                filter &= Builders<Ticket>.Filter.Gte(t => t.StartDate, startDate.Value);

            filter &= Builders<Ticket>.Filter.Eq(t => t.IsDeleted, false);

            return await _collection.Find(filter).ToListAsync();
        }

        public async Task<List<Ticket>> GetPaginated(int page, int pageSize)
        {
            return await _collection
                .Find(t => !t.IsDeleted)
                .Skip((page - 1) * pageSize)
                .Limit(pageSize)
                .ToListAsync();
        }
    }
}
