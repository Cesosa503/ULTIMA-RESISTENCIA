﻿using MongoAPI.Models;
using MongoAPI.Repositories;

namespace MongoAPI.Services
{
    public class TicketService
    {
        private readonly TicketRepository _repo;

        public TicketService(TicketRepository repo)
        {
            _repo = repo;
        }

        public async Task<List<Ticket>> GetAll()
        {
            return await _repo.GetAll();
        }

        public async Task<Ticket> GetById(string id)
        {
            return await _repo.GetById(id);
        }

        public async Task Create(Ticket ticket)
        {
            await _repo.Create(ticket);
        }

        public async Task Update(string id, Ticket ticket)
        {
            await _repo.Update(id, ticket);
        }

        public async Task Delete(string id)
        {
            await _repo.Delete(id);
        }

        public async Task<List<Ticket>> Filter(string? title, string? status, DateTime? startDate)
        {
            return await _repo.Filter(title, status, startDate);
        }

        public async Task<List<Ticket>> GetPaginated(int page, int pageSize)
        {
            return await _repo.GetPaginated(page, pageSize);
        }

    }
}