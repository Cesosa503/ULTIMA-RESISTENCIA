@echo off

set FECHA=%date:~10,4%-%date:~4,2%-%date:~7,2%
set HORA=%time:~0,2%-%time:~3,2%

"C:\mongodb-tools\bin\mongodump.exe" ^
--uri="mongodb://localhost:27017" ^
--gzip ^
--archive="mongo-backups\backup-%FECHA%-%HORA%.gz"

echo Backup realizado correctamente
pause