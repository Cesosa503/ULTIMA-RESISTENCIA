# Backup Automático de MongoDB — MongoAPI

Programa externo para realizar copias de seguridad automáticas de la base de datos MongoDB del proyecto de cátedra. Desarrollado como parte del **Entregable 2 — Semana 11 (Implementación MongoDB)**.

> **Proyecto:** MongoAPI (C# / ASP.NET Core)
> **Base de datos:** `MongoDB` | **Colección:** `Tickets` | **Host:** `localhost:27017`

---

## Requisitos previos

Antes de usar este script, asegúrate de tener instalado lo siguiente:

|Herramienta|Versión mínima|Descarga|
|-|-|-|
|Python|3.8+|https://www.python.org/downloads/|
|MongoDB Database Tools|Última|https://www.mongodb.com/try/download/database-tools|

> **Importante:** MongoDB Database Tools incluye `mongodump`, la herramienta que realiza el backup. Es un paquete separado de MongoDB y debe instalarse por aparte.

### Verificar instalación

Abre una terminal (CMD o PowerShell) y ejecuta:

```bash
python --version
mongodump --version
```

Ambos comandos deben mostrar su versión sin errores.

---

## Configuración

Abre el archivo `backup_mongo.py` y edita las variables al inicio del archivo:

```python
MONGO_HOST     = "localhost"
MONGO_PORT     = "27017"
MONGO_DB       = "MongoDB"
MONGO_USER     = ""
MONGO_PASSWORD = ""
```

> **El script ya está preconfigurado** con los valores del `appsettings.json` del proyecto. No necesitas cambiar nada si trabajas en local.

---

## Cómo ejecutar el backup

### Opción 1 — Manualmente (una sola vez)

Abre CMD o PowerShell en la carpeta del proyecto y ejecuta:

```bash
python backup_mongo.py
```

### Opción 2 — Automático con el Programador de Tareas de Windows

1. Presiona `Win + R`, escribe `taskschd.msc` y da Enter.
2. Clic en **"Crear tarea básica..."** en el panel derecho.
3. Ponle un nombre: `Backup MongoDB Proyecto`.
4. En **Desencadenador**, elige **Diariamente** y la hora que prefieras.
5. En **Acción**, elige **Iniciar un programa** y configura:
   * **Programa:** `python`
   * **Argumentos:** `backup_mongo.py`
   * **Iniciar en:** la ruta completa a la carpeta del proyecto
6. Finalizar y guardar.

---

## Estructura de archivos generados

tu-proyecto/
├── backup_mongo.py
├── README.md
└── backups/
├── backup_2026-04-10_22-00-00/
│   └── MongoDB/
│       ├── Tickets.bson
│       └── Tickets.metadata.json
└── backup_2026-04-11_14-30-00/
└── MongoDB/
├── Tickets.bson
└── Tickets.metadata.json

---

## Cómo restaurar un backup

```bash
mongorestore --host=localhost --port=27017 --db=MongoDB backups\\backup_2026-04-11_14-30-00\\MongoDB
```

---

## Errores comunes

|Error|Causa|Solución|
|-|-|-|
|`'mongodump' no fue encontrado`|MongoDB Tools no instalado|Instalar desde el enlace de Requisitos|
|`Connection refused`|MongoDB no está corriendo|Iniciar el servicio de MongoDB|
|`Authentication failed`|Credenciales incorrectas|Verificar usuario y contraseña en el script|

---

## Autor

Proyecto desarrollado por Gruppo A.

---

## Replica Set y Sharding — MongoDB con Docker

Configuración de alta disponibilidad y escalabilidad horizontal para StudyHub.

### Requisitos previos

| Herramienta | Versión mínima | Descarga |
|-|-|-|
| Docker Desktop | Última | https://www.docker.com/products/docker-desktop |

### Cómo levantar el cluster

1. Asegúrate de tener Docker Desktop abierto y corriendo.
2. Abre una terminal en la carpeta donde está el `docker-compose.yml` y ejecuta:

```bash
docker-compose up -d
```

3. Inicializa el Replica Set:

```bash
docker exec -it mongo1 mongosh --port 27017 --eval "rs.initiate({_id:'rs0',members:[{_id:0,host:'mongo1:27017'},{_id:1,host:'mongo2:27018'},{_id:2,host:'mongo3:27019'}]})"
```

4. Inicializa el Config Server:

```bash
docker exec -it configsvr mongosh --port 27020 --eval "rs.initiate({_id:'configrs',members:[{_id:0,host:'configsvr:27020'}]})"
```

5. Agrega el Shard:

```bash
docker exec -it mongos mongosh --port 27021 --eval "sh.addShard('rs0/mongo1:27017,mongo2:27018,mongo3:27019')"
```

6. Habilita el Sharding en StudyHub:

```bash
docker exec -it mongos mongosh --port 27021 --eval "sh.enableSharding('studyhub')"
docker exec -it mongos mongosh --port 27021 --eval "sh.shardCollection('studyhub.users', {_id: 'hashed'})"
docker exec -it mongos mongosh --port 27021 --eval "sh.shardCollection('studyhub.contents', {_id: 'hashed'})"
docker exec -it mongos mongosh --port 27021 --eval "sh.shardCollection('studyhub.recommendations', {_id: 'hashed'})"
docker exec -it mongos mongosh --port 27021 --eval "sh.shardCollection('studyhub.analytics', {_id: 'hashed'})"
```

7. Verifica que todo esté funcionando:

```bash
docker exec -it mongos mongosh --port 27021 --eval "sh.status()"
```

### Estructura del cluster

| Contenedor | Rol | Puerto |
|-|-|-|
| mongo1 | Nodo Primary | 27017 |
| mongo2 | Nodo Secondary | 27018 |
| mongo3 | Nodo Secondary | 27019 |
| configsvr | Config Server | 27020 |
| mongos | Router | 27021 |

---

## Endpoints de la API

Base URL: `http://localhost:5000/api/Ticket`

| Método | Endpoint | Descripción |
|-|-|-|
| POST | /api/Ticket | Crear un ticket |
| GET | /api/Ticket | Obtener todos los tickets |
| GET | /api/Ticket/{id} | Obtener ticket por ID |
| PUT | /api/Ticket/{id} | Actualizar un ticket |
| DELETE | /api/Ticket/{id} | Eliminar un ticket |
| GET | /api/Ticket/filter | Filtrar por título, estado o fecha |
| GET | /api/Ticket/paginated | Obtener tickets paginados |

### Filtros disponibles
- `title` → filtra por título
- `status` → filtra por estado
- `startDate` → filtra por fecha de inicio

### Paginación
- `page` → número de página (default: 1)
- `pageSize` → cantidad por página (default: 5)